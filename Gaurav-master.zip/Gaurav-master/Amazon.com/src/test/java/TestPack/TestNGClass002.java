package TestPack;

public class TestNGClass002 {

}
